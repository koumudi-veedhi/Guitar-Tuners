/**
 * main.js — AppController
 * Coordinates all modules:
 *   VideoSource → HandTrackingService → FretboardMapper → ChordModel → OverlayRenderer
 * Also manages UI state, calibration, chord selection, and score display.
 */

import { VideoSource } from './VideoSource.js';
import { HandTrackingService } from './HandTrackingService.js';
import { FretboardMapper } from './FretboardMapper.js';
import { ChordModel } from './ChordModel.js';
import { OverlayRenderer } from './OverlayRenderer.js';

// ── DOM Refs ────────────────────────────────────────────────────────────────

const video = document.getElementById('webcamVideo');
const canvas = document.getElementById('overlayCanvas');
const placeholder = document.getElementById('videoPlaceholder');
const calibBox = document.getElementById('calibrationBox');
const hintText = document.getElementById('hintText');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const scoreCircle = document.getElementById('scoreCircle');
const scoreNumber = document.getElementById('scoreNumber');
const scoreLabel = document.getElementById('scoreLabel');
const fingerStatus = document.getElementById('fingerStatus');
const chordChart = document.getElementById('chordChart');
const tipsList = document.getElementById('tipsList');

const btnStart = document.getElementById('btnStartCamera');
const btnStop = document.getElementById('btnStopCamera');
const btnCalibrate = document.getElementById('btnCalibrate');
const btnConfirm = document.getElementById('btnConfirmCalibration');
const btnCancel = document.getElementById('btnCancelCalibration');
const chordSelect = document.getElementById('chordSelect');

// ── Module instances ─────────────────────────────────────────────────────────

const videoSource = new VideoSource(video);
const handTracker = new HandTrackingService();
const fretMapper = new FretboardMapper();
const chordModel = new ChordModel();
const renderer = new OverlayRenderer(canvas);

// ── State ──────────────────────────────────────────────────────────────────

let isRunning = false;
let isCalibrating = false;
let rafId = null;
let modelLoading = false;

// ── Status helpers ─────────────────────────────────────────────────────────

function setStatus(text, type = 'idle') {
    statusText.textContent = text;
    statusDot.className = 'status-dot' + (type === 'active' ? ' active' : type === 'error' ? ' error' : '');
}

function setHint(text) {
    hintText.textContent = text;
}

// ── Score UI ────────────────────────────────────────────────────────────────

const CIRCUMFERENCE = 2 * Math.PI * 42; // circle r=42

function updateScoreUI(result) {
    if (!result || result.total === 0) {
        scoreNumber.textContent = '—';
        const hasChord = chordSelect && chordSelect.value;
        if (!hasChord) {
            scoreLabel.textContent = 'No chord selected';
        } else if (!isRunning) {
            scoreLabel.textContent = 'Start camera to detect';
        } else {
            scoreLabel.textContent = 'Hold chord in ROI';
        }
        scoreCircle.style.strokeDashoffset = CIRCUMFERENCE;
        scoreCircle.style.stroke = 'var(--text-muted)';
        fingerStatus.innerHTML = '';
        return;
    }

    const pct = result.score / result.total;
    const offset = CIRCUMFERENCE * (1 - pct);
    const color = pct >= 0.8 ? 'var(--success)' : pct >= 0.5 ? 'var(--warning)' : 'var(--danger)';

    scoreCircle.style.strokeDashoffset = offset;
    scoreCircle.style.stroke = color;
    scoreNumber.textContent = `${Math.round(pct * 100)}%`;
    scoreLabel.textContent = `${result.score} / ${result.total} fingers correct`;

    // Finger badges
    fingerStatus.innerHTML = result.details.map((d, i) =>
        `<span class="finger-badge ${d.hit ? 'correct' : 'incorrect'}">
      ${['Thumb', 'Idx', 'Mid', 'Ring', 'Pink'][i] ?? `F${i + 1}`}
    </span>`
    ).join('');
}

// ── Chord Chart panel ───────────────────────────────────────────────────────

const STRING_LABELS = ['6', '5', '4', '3', '2', '1'];

function renderChordChart(chordName) {
    const shape = chordModel.getChordShape(chordName);
    if (!shape) {
        chordChart.innerHTML = '<p class="hint-text">Select a chord to see its fingering chart.</p>';
        return;
    }

    const rows = STRING_LABELS.map((lbl, i) => {
        const fret = shape[i];
        const indicator = fret === -1 ? '✕' : fret === 0 ? 'O' : `${fret}`;
        const cls = fret === -1 ? 'muted' : fret === 0 ? 'open' : 'fret';
        return `<div class="chart-row">
      <span class="chart-string">${lbl}</span>
      <span class="chart-fret ${cls}">${indicator}</span>
    </div>`;
    }).join('');

    chordChart.innerHTML = `
    <div class="chord-name-label">${chordName}</div>
    <div class="chart-grid">${rows}</div>
    <div class="chord-frets-label">Lo ← strings → Hi</div>
  `;
}

// ── Calibration UI ──────────────────────────────────────────────────────────

function startCalibration() {
    isCalibrating = true;
    calibBox.classList.remove('hidden');
    btnCalibrate.classList.add('hidden');
    btnConfirm.classList.remove('hidden');
    btnCancel.classList.remove('hidden');
    setHint('📐 Drag to align the blue box with your guitar neck, then click Confirm.');
    makeDraggableResizable(calibBox);
}

function confirmCalibration() {
    const wrapper = document.getElementById('videoWrapper');
    const wRect = wrapper.getBoundingClientRect();
    const bRect = calibBox.getBoundingClientRect();

    // Convert to canvas-relative coordinates
    const scaleX = canvas.width / wRect.width;
    const scaleY = canvas.height / wRect.height;

    // Because video is mirrored (scaleX(-1)), flip the x coordinate
    const x = (wRect.width - (bRect.left - wRect.left) - bRect.width) * scaleX;
    const y = (bRect.top - wRect.top) * scaleY;

    fretMapper.setROI({
        x,
        y,
        width: bRect.width * scaleX,
        height: bRect.height * scaleY,
    });
    fretMapper.saveToStorage();

    endCalibration();
    setHint('✅ Calibration saved! Now select a chord and start playing.');
}

function endCalibration() {
    isCalibrating = false;
    calibBox.classList.add('hidden');
    btnCalibrate.classList.remove('hidden');
    btnConfirm.classList.add('hidden');
    btnCancel.classList.add('hidden');
}

// ── Drag + Resize calibration box ──────────────────────────────────────────

function makeDraggableResizable(el) {
    const corners = el.querySelectorAll('.calib-corner');
    let action = null, startX, startY, startRect;

    const getRect = () => ({
        left: parseInt(el.style.left || el.offsetLeft),
        top: parseInt(el.style.top || el.offsetTop),
        width: el.offsetWidth,
        height: el.offsetHeight,
    });

    const onMove = (e) => {
        if (!action) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        const { left, top, width, height } = startRect;

        if (action === 'drag') {
            el.style.left = (left + dx) + 'px';
            el.style.top = (top + dy) + 'px';
        } else if (action === 'br') {
            el.style.width = Math.max(60, width + dx) + 'px';
            el.style.height = Math.max(40, height + dy) + 'px';
        } else if (action === 'bl') {
            el.style.left = (left + dx) + 'px';
            el.style.width = Math.max(60, width - dx) + 'px';
            el.style.height = Math.max(40, height + dy) + 'px';
        } else if (action === 'tr') {
            el.style.top = (top + dy) + 'px';
            el.style.width = Math.max(60, width + dx) + 'px';
            el.style.height = Math.max(40, height - dy) + 'px';
        } else if (action === 'tl') {
            el.style.left = (left + dx) + 'px';
            el.style.top = (top + dy) + 'px';
            el.style.width = Math.max(60, width - dx) + 'px';
            el.style.height = Math.max(40, height - dy) + 'px';
        }
    };

    const onUp = () => { action = null; };

    el.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('calib-corner')) return;
        e.preventDefault();
        action = 'drag'; startX = e.clientX; startY = e.clientY;
        startRect = getRect();
    });

    corners.forEach(c => {
        const type = [...c.classList].find(cl => ['tl', 'tr', 'bl', 'br'].includes(cl));
        c.addEventListener('mousedown', (e) => {
            e.preventDefault(); e.stopPropagation();
            action = type; startX = e.clientX; startY = e.clientY;
            startRect = getRect();
        });
    });

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
}

// ── Main render loop ─────────────────────────────────────────────────────────

async function renderLoop() {
    if (!isRunning) return;

    renderer.syncSize(video);
    renderer.clear();

    const cw = canvas.width;
    const ch = canvas.height;

    // Use saved ROI or set a default
    if (!fretMapper.hasROI()) {
        fretMapper.setROI(fretMapper.getDefaultROI(cw, ch));
    }

    const roi = fretMapper.roi;
    const grid = fretMapper.getGridLines();
    renderer.drawFretboardGrid(roi, grid);

    // Draw target chord dots
    const shape = chordModel.getCurrentChordShape();
    if (shape) {
        const targetPositions = [];
        for (let s = 0; s < 6; s++) {
            const fret = shape[s];
            if (fret > 0) {
                // string index: 0=low-E → string number 6 (bottom of ROI in neck-up view)
                // In the fretboard we defined string 1 at top (high-e visual), 6 at bottom
                // Chord data: index 0=string6(lowE), display top=string1(high-e)
                // So stringNum in ROI = (6 - s)
                const pos = fretMapper.getFretboardPixel(6 - s, fret);
                if (pos) targetPositions.push(pos);
            }
        }
        renderer.drawTargetDots(targetPositions);
    }

    // Run hand detection
    const landmarks = handTracker.detectForVideo(video, performance.now());
    let compareResult = null;

    if (landmarks && landmarks.length > 0) {
        const hand = landmarks[0]; // single hand (index 0)

        // Draw skeleton
        renderer.drawHandSkeleton(hand, cw, ch);

        // Get fingertips
        const tips = handTracker.getFingertips(hand);

        // Map to fretboard coords
        const mappedFingers = tips.map(tip => {
            // Landmarks are normalized 0..1; convert to canvas pixels
            const px = tip.x * cw;
            const py = tip.y * ch;
            return fretMapper.mapToFretboard(px, py);
        });

        // Compare to chord
        if (shape) {
            compareResult = chordModel.compareFingers(mappedFingers);
            renderer.drawScoreOverlay(compareResult, roi);
        }

        // Draw fingertip dots
        const tipDots = tips.map((tip, i) => {
            const px = tip.x * cw;
            const py = tip.y * ch;
            const inROI = fretMapper.isInROI(px, py);
            const mapped = mappedFingers[i];
            const correct = compareResult && compareResult.details.some(d =>
                mapped && Math.abs(d.target.string - mapped.string) <= 1 &&
                Math.abs(d.target.fret - mapped.fret) <= 1 && d.hit
            );
            return { cx: px, cy: py, inROI, correct };
        });
        renderer.drawFingertipDots(tipDots);
    }

    updateScoreUI(compareResult);

    rafId = requestAnimationFrame(renderLoop);
}

// ── Camera ───────────────────────────────────────────────────────────────────

async function startCamera() {
    btnStart.disabled = true;
    setStatus('Starting camera…');
    setHint('📷 Requesting camera access…');

    const ok = await videoSource.start();
    if (!ok) {
        setStatus('Camera error', 'error');
        setHint('❌ Camera access denied. Please allow camera permissions and try again.');
        btnStart.disabled = false;
        return;
    }

    placeholder.classList.add('hidden');
    btnStart.disabled = true;
    btnStop.disabled = false;
    btnCalibrate.disabled = false;
    isRunning = true;
    setStatus('Camera active', 'active');
    setHint('🔄 Loading hand-tracking AI model…');

    // Load model (only once)
    if (!handTracker.isReady && !modelLoading) {
        modelLoading = true;
        await handTracker.init();
        modelLoading = false;
    }

    setHint('✅ Ready! Select a chord and point camera at your guitar neck.');
    rafId = requestAnimationFrame(renderLoop);
}

function stopCamera() {
    isRunning = false;
    if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
    videoSource.stop();
    renderer.clear();
    placeholder.classList.remove('hidden');
    btnStart.disabled = false;
    btnStop.disabled = true;
    btnCalibrate.disabled = true;
    setStatus('Ready');
    setHint('📷 Click Start Camera to begin.');
    updateScoreUI(null);
}

// ── Event listeners ──────────────────────────────────────────────────────────

btnStart.addEventListener('click', startCamera);
btnStop.addEventListener('click', stopCamera);

btnCalibrate.addEventListener('click', startCalibration);
btnConfirm.addEventListener('click', confirmCalibration);
btnCancel.addEventListener('click', () => { endCalibration(); setHint('Calibration cancelled.'); });

chordSelect.addEventListener('change', (e) => {
    const name = e.target.value;
    chordModel.setCurrentChord(name || null);
    if (name) {
        renderChordChart(name);
        setHint(`🎯 Playing ${name} — Press your fingers on the highlighted positions.`);
    } else {
        chordChart.innerHTML = '<p class="hint-text">Select a chord to see its fingering chart.</p>';
        setHint('🎸 Select a chord from the dropdown to begin.');
    }
    updateScoreUI(null);
});

// Resize canvas when window resizes
window.addEventListener('resize', () => {
    if (isRunning) renderer.syncSize(video);
});

// ── Inject dynamic chart styles ───────────────────────────────────────────────

const chartStyles = document.createElement('style');
chartStyles.textContent = `
  .chart-grid { display: flex; flex-direction: column; gap: 3px; margin: 8px 0; }
  .chart-row  { display: flex; align-items: center; gap: 8px; font-size: 0.75rem; }
  .chart-string { color: var(--text-muted); width: 14px; text-align: right; font-size: 0.7rem; }
  .chart-fret { padding: 2px 8px; border-radius: 4px; font-weight: 700; min-width: 32px; text-align: center; }
  .chart-fret.fret  { background: rgba(79,156,249,0.18); color: var(--accent); border: 1px solid rgba(79,156,249,0.3); }
  .chart-fret.open  { background: rgba(45,212,160,0.12); color: var(--success); border: 1px solid rgba(45,212,160,0.25); }
  .chart-fret.muted { background: rgba(249,112,102,0.1); color: var(--danger);  border: 1px solid rgba(249,112,102,0.2); }
`;
document.head.appendChild(chartStyles);

// ── Init ──────────────────────────────────────────────────────────────────────

setStatus('Ready');
setHint('🎸 Start camera and select a chord to begin coaching.');
