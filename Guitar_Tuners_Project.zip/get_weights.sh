gdown https://drive.google.com/uc?id=1n7Cwc7UWHaZ88vGpPoLlX_yJnAu1L6TT

mkdir best_ckpt

mv UCCS-UB-guitar-weights.zip best_ckpt/ckpts.zip

cd best_ckpt

unzip ckpts.zip

rm ckpts.zip

