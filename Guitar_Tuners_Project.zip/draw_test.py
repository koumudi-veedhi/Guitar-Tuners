import cv2

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    h, w, c = frame.shape

    # Draw rectangle (fretboard area)
    x1, y1 = 100, 100
    x2, y2 = 500, 300
    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

    # Draw horizontal lines (strings)
    for i in range(1, 6):
        y = y1 + i * (y2 - y1) // 6
        cv2.line(frame, (x1, y), (x2, y), (255, 0, 0), 1)

    # Draw vertical lines (frets)
    for i in range(1, 5):
        x = x1 + i * (x2 - x1) // 5
        cv2.line(frame, (x, y1), (x, y2), (0, 0, 255), 1)

    cv2.imshow("Grid Test", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
