gdown https://drive.google.com/uc?id=1Bh_MMfSJm1BqqxL7bZyO4bSREODSHZYL
unzip UCCS-UB-guitar-dataset.zip
mv UCCS-UB-guitar-dataset/* .
rm -r UCCS-UB-guitar-dataset UCCS-UB-guitar-dataset.zip
