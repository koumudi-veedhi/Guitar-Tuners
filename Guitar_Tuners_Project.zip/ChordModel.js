/**
 * ChordModel.js
 * Loads chord data from JSON and compares detected finger positions
 * to target chord shapes.
 */
import CHORD_DATA from './chord_data.json';

/** Human-readable names for each finger */
const FINGER_NAMES = ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky'];

/** Guitar string names (index 0 = string 6 = low E) */
const STRING_NAMES = ['6 (Low E)', '5 (A)', '4 (D)', '3 (G)', '2 (B)', '1 (High e)'];

export class ChordModel {
    constructor() {
        this._data = CHORD_DATA;
        this._currentChord = null;
    }

    /** @returns {string[]} list of available chord names */
    get availableChords() {
        return Object.keys(this._data);
    }

    /**
     * Get the fret array for a chord.
     * Returns an array of 6 values (string 6 → string 1):
     *   -1 = muted, 0 = open, N = fret number
     * @param {string} chordName
     * @returns {number[]|null}
     */
    getChordShape(chordName) {
        return this._data[chordName] ?? null;
    }

    setCurrentChord(name) {
        this._currentChord = name;
    }

    getCurrentChordShape() {
        if (!this._currentChord) return null;
        return this.getChordShape(this._currentChord);
    }

    /**
     * Compare detected finger positions to the current chord shape.
     * @param {Array<{string: number, fret: number}|null>} detectedFingers
     *   Array of 5 mapped positions (thumb through pinky), or null if finger not in ROI.
     * @returns {{ score: number, total: number, details: Array }}
     */
    compareFingers(detectedFingers) {
        const shape = this.getCurrentChordShape();
        if (!shape || !detectedFingers) {
            return { score: 0, total: 0, details: [] };
        }

        // Build list of fretted string targets (strings that need a finger)
        // shape[i] where i is string index (0=low E), value = fret (or -1/0)
        const targets = [];
        for (let s = 0; s < 6; s++) {
            const fret = shape[s];
            if (fret > 0) {
                // This string needs a pressed finger
                targets.push({ string: s + 1, fret }); // 1-indexed string
            }
        }

        if (targets.length === 0) {
            return { score: 0, total: 0, details: [] };
        }

        // For each target, find the closest detected finger
        const tolerance = 1; // allow ±1 fret / string error
        let correct = 0;
        const details = targets.map(target => {
            const hit = detectedFingers.some(f => {
                if (!f) return false;
                return Math.abs(f.string - target.string) <= tolerance &&
                    Math.abs(f.fret - target.fret) <= tolerance;
            });
            if (hit) correct++;
            return { target, hit };
        });

        return { score: correct, total: targets.length, details };
    }

    /** Returns display info for the chord chart panel */
    getChordDisplayInfo(chordName) {
        const shape = this.getChordShape(chordName);
        if (!shape) return null;
        return {
            name: chordName,
            shape,
            stringNames: STRING_NAMES,
        };
    }
}
